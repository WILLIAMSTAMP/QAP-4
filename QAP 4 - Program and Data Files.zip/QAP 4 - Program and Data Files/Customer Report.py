import datetime
# One Stop Insurance - Policy Reports
# Written by: William Stamp
# Written on: April 4 2022


CurDate = datetime.datetime.now()
print()
print()
print("ONE STOP INSURANCE COMPANY")
print("POLICY LISTING AS OF {}".format(CurDate.strftime("%m-%b-%Y")))
print()
print("POLICY  CUSTOMER           INSURANCE      EXTRA        TOTAL ")
print("NUMBER  NAME                PREMIUM       COSTS       PREMIUM ")
print("=" * 61)
CustCtr = 0
PremAcc = 0
ExtrasCostAcc = 0
TotCostAcc = 0
f = open("Policies.dat", "r")

for CustDataLine in f:
    CustLine = CustDataLine.split(", ")
    PolicyNum = CustLine[0].strip()
    CustFName = CustLine[1].strip()
    CustLName = CustLine[2].strip()
    ExtrasCost = CustLine[13].strip()
    Premium = CustLine[14].strip()
    TotCost = CustLine[15].strip()

    PremiumR = float(Premium)
    ExtrasCostR = float(ExtrasCost)
    TotCostR = float(TotCost)

    TotCostDsp = "${:,.2f}".format(TotCostR)
    ExtrasCostDsp = "${:,.2f}".format(ExtrasCostR)
    PremiumDsp = "${:,.2f}".format(PremiumR)

    print("{:<4}  {:<8}  {:<8}  {:>10}  {:>10}   {:>10}".format(PolicyNum, CustFName, CustLName, PremiumDsp,
                                                                ExtrasCostDsp, TotCostDsp))
    CustCtr += 1
    PremAcc += PremiumR
    ExtrasCostAcc += ExtrasCostR
    TotCostAcc += TotCostR

f.close()
print("=" * 61)
PremAccDsp = "${:,.2f}".format(PremAcc)
ExtrasCostAccDsp = "${:,.2f}".format(ExtrasCostAcc)
TotCostAccDsp = "${:,.2f}".format(TotCostAcc)
print("Customers listed: {}       {:>8} {:>11}   {:>10}".format(CustCtr, PremAccDsp, ExtrasCostAccDsp, TotCostAccDsp))
print()
print(" " * 23, "End of Listing")

#
#
#
#

CurDate = datetime.datetime.now()
print()
print()
print("ONE STOP INSURANCE COMPANY")
print("MONTHLY PAYMENT LISTING AS OF {}".format(CurDate.strftime("%m-%b-%Y")))
print()
print("POLICY  CUSTOMER            TOTAL                    TOTAL      MONTHLY ")
print("NUMBER  NAME               PREMIUM        HST        COST       PAYMENT ")
print("=" * 71)

CustCtr = 0
PremAcc = 0
HSTAcc = 0
TotCostAcc = 0
MonthPayAcc = 0
f = open("Payments.dat", "r")
for CustDataLine in f:
    CustLine = CustDataLine.split(", ")
    PolicyNum = CustLine[0].strip()
    CustFName = CustLine[1].strip()
    CustLName = CustLine[2].strip()
    TotPrem = CustLine[5].strip()
    HST = CustLine[4].strip()
    TotCost = CustLine[6].strip()
    MonthPay = CustLine[7].strip()
    Premium = float(TotPrem)
    HST = float(HST)
    TotCost = float(TotCost)
    MonthPay = float(MonthPay)
    TotCostDsp = "${:,.2f}".format(TotCost)
    HSTDsp = "${:,.2f}".format(HST)
    PremiumDsp = "${:,.2f}".format(Premium)
    MonthPayDsp = "${:,.2f}".format(MonthPay)
    print("{:<8}{:<8}{:<8} {:>10}  {:>10}   {:>10} {:>10}".format(PolicyNum, CustFName, CustLName, PremiumDsp, HSTDsp,
                                                                  TotCostDsp, MonthPayDsp))
    CustCtr += 1
    PremAcc += Premium
    HSTAcc += HST
    TotCostAcc += TotCost
    MonthPayAcc += MonthPay
f.close()
print("=" * 71)
PremAccDsp = "${:,.2f}".format(PremAcc)
HSTAccDsp = "${:,.2f}".format(HSTAcc)
TotCostAccDsp = "${:,.2f}".format(TotCostAcc)
MonthPayAccDsp = "${:,.2f}".format(MonthPayAcc)
print("Customers listed: {}     {:>10}   {:>10}   {:>10}  {:>8}".format(CustCtr, PremAccDsp, HSTAccDsp, TotCostAccDsp,
                                                                        MonthPayAccDsp))
print()
print(" " * 26, "End of Listing")
