from datetime import date
# One Stop Insurance - Policies and Reports
# Program writen by: William Stamp
# Written on: April 4 2022

# Commented out because data files are created
'''
CLAIM_NUM = 1944
BASIC_PREM = 869.00
ADD_CAR_DISC = .25
EXTRA_COV = 130.00
GLASS_COV = 86.00
LOAN_CAR_COV = 58.00
HST_RATE = .15
PROCESS_FEE = 39.99
f = open('OSICDef.dat', 'w')
f.write("{}\n".format(str(CLAIM_NUM)))
f.write("{}\n".format(BASIC_PREM))
f.write("{}\n".format(ADD_CAR_DISC))
f.write("{}\n".format(EXTRA_COV))
f.write("{}\n".format(GLASS_COV))
f.write("{}\n".format(LOAN_CAR_COV))
f.write("{}\n".format(str(HST_RATE)))
f.write("{}\n".format(PROCESS_FEE))
f.close()
'''
# Read from "OSICDef.dat" for constants

f = open('OSICDef.dat', 'r')
POLICY_NUM = int(f.readline())
BASIC_PREM = float(f.readline())
ADD_CAR_DISC = float(f.readline())
EXTRA_COV = float(f.readline())
GLASS_COV = float(f.readline())
LOAN_CAR_COV = float(f.readline())
HST_RATE = float(f.readline())
PROCESS_FEE = float(f.readline())
f.close()

# User input------------------------------------------------------------------------------------------------------------

while True:
    while True:
        today = date.today()
        print()
        print("                            One Stop Insurance Company")
        print("                             Insurance Policy Program")
        print()
        print("                                                               Today's Date: {:}".format(today))
        print("----------------------------------------------------------------------------------------")
        print()
        allowed_char = "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwqyz-' "
        CustFirstNm = input("Enter the customers first name: ").title()
        if CustFirstNm == "":
            print("Field Cannot Be Blank - Please enter the customers first name. ")
        elif not set(CustFirstNm).issubset(allowed_char):
            print("Last name contains invalid characters - Please re-enter the customers first name: ")
        else:
            break

    while True:
        allowed_char = "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwqyz-' "
        CustLastNm = input("Enter the customers last name: ").title()
        if CustLastNm == "":
            print("Field Cannot Be Blank - Please enter the Customers last name. ")
        elif not set(CustLastNm).issubset(allowed_char):
            print("Last name contains invalid characters - Please re-enter the customers last name: ")
        else:
            break

    while True:
        allowed_char = "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwxqyz 1234567890.-' "
        CustStAdd = input("Enter the customers street address: ").title()
        if CustStAdd == "":
            print("This field Cannot Be Blank - Please enter the customers street address. ")
        elif not set(CustStAdd).issubset(allowed_char):
            print("The field contains invalid characters - Please re-enter the street address. ")
        else:
            break

    while True:
        allowed_char = "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwqyz.-' "
        CustCity = input("Enter the customers city: ").title()
        if CustCity == "":
            print("This field Cannot Be Blank - Please enter the customers city. ")
        elif not set(CustCity).issubset(allowed_char):
            print("The field contains invalid characters - Please re-enter the city. ")
        else:
            break

    while True:
        allowed_char = "ABCDEFGHIJKLMNOPQRSTUVWXYZ abcdefghijklmnopqrstuvwqyz-' "
        CustProv = input("Enter the customers province: ").title()
        if CustProv == "":
            print("This field Cannot Be Blank - Please enter the customers province. ")
        elif not set(CustProv).issubset(allowed_char):
            print("The field contains invalid characters - Please re-enter the province. ")
        else:
            break

    while True:
        allowed_char = set("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz 1234567890")
        PostCode = input("Please enter your postal code  (A1A1A1): ").upper()
        if not set(PostCode).issubset(allowed_char):
            print("Postal Code contains invalid characters - Please Re-enter.")
        elif PostCode == "":
            print("Postal code cannot be blank - Please enter postal code. ")
        else:
            break

    while True:
        allowed_char = "1234567890-"
        CustPh = input("Enter the customers phone Number (xxx-xxx-xxxx): ")
        if not set(CustPh).issubset(allowed_char):
            print("Field contains invalid characters - Please re-enter the customers phone number. ")
        elif CustPh == "":
            print("Field cannot be blank - Please enter the customers phone number. ")
        elif len(CustPh) != 12:
            print("Phone number must include area code and should be 10 digits - please try again: ")
        else:
            break

    while True:
        NumCars = int(input("Enter the number of cars that require coverage: "))
        if NumCars == "":
            print("Field cannot be empty - Please enter the number of cars that require coverage. ")
        else:
            break

    while True:
        allowed_char = "YyNn"
        ExtLiability = input("Extra liability coverage ( Y = Yes / N = No ): ").upper()
        if not set(ExtLiability).issubset(allowed_char):
            print("Invalid Input - Extra liability coverage option. ( Y = Yes / N = No ):")
        elif ExtLiability == "":
            print("Field cannot be empty - Extra liability coverage option. ( Y = Yes / N = No ): ")
        else:
            break

    while True:
        allowed_char = "YyNn"
        GlassCov = input("Glass Coverage ( Y = Yes / N = No ): ").upper()
        if not set(GlassCov).issubset(allowed_char):
            print("Invalid Input - Glass coverage option. ( Y = Yes / N = No ):")
        elif ExtLiability == "":
            print("Field cannot be empty - Glass coverage option. ( Y = Yes / N = No ): ")
        else:
            break

    while True:
        allowed_char = "YyNn"
        LoanCar = input("Loan vehicle (Y = Yes / N = No ): ").upper()
        if not set(LoanCar).issubset(allowed_char):
            print("Invalid Input - Loan vehicle option. ( Y = Yes / N = No ):")
        elif LoanCar == "":
            print("Field cannot be empty - Loan vehicle option. ( Y = Yes / N = No ): ")
        else:
            break

    while True:
        allowed_char = "MmFf"
        PolPayMethod = input("Enter the customers preferred payment arrangement. ( F = Full / M = Monthly ): ").upper()
        if not set(PolPayMethod).issubset(allowed_char):
            print("Invalid Input - Policy Payment method. ( F = Full / M = Monthly ):")
        elif PolPayMethod == "":
            print("Field cannot be empty - Policy Payment method. ( F = Full / M = Monthly ): ")
        else:
            break

# Calculations----------------------------------------------------------------------------------------------------------

    while True:
        if ExtLiability == "Y":
            ExtraCovCost = EXTRA_COV * NumCars
        else:
            ExtraCovCost = 0

        if GlassCov == "Y":
            GlassCovCost = GLASS_COV * NumCars
        else:
            GlassCovCost = 0

        if LoanCar == "Y":
            LoanCarCost = LOAN_CAR_COV * NumCars
        else:
            LoanCarCost = 0

        Premium = 0
        if NumCars == 1:
            Premium = BASIC_PREM
        else:                               # -----------------Discount-------------------
            Premium = BASIC_PREM * NumCars - (BASIC_PREM * (NumCars - 1) * ADD_CAR_DISC)
        Discount = NumCars - (BASIC_PREM * (NumCars - 1) * ADD_CAR_DISC)
        TotExtra = ExtraCovCost + GlassCovCost + LoanCarCost
        TotPremium = Premium + TotExtra
        Taxes = TotPremium * HST_RATE
        TotPremCost = TotPremium + Taxes
        MonthlyPay = (TotPremCost / 12) + PROCESS_FEE
        break

    today = date.today()
    d1 = today.strftime("%b %d, %Y")
    d1Dsp = d1
    NumCarsDsp = "{:}".format(NumCars)
    DiscountDsp = "${:,.2f}".format(Discount)
    TotExtraDsp = "${:,.2f}".format(TotExtra)
    TotPremiumDsp = "${:,.2f}".format(TotPremium)
    ExtLiabilityDsp = "${:,.2f}".format(ExtraCovCost)
    GlassCovCostDsp = "${:,.2f}".format(GlassCovCost)
    LoanCarCostDsp = "${:,.2f}".format(LoanCarCost)
    TaxesDsp = "${:,.2f}".format(Taxes)
    TotCostDsp = "${:,.2f}".format(TotPremCost)
    PolPayMethodDsp = "{:}".format(PolPayMethod)
    MonthlyPayDsp = "${:,.2f}".format(MonthlyPay)
    PremiumCostDsp = "${:,.2f}".format(Premium)
    NADsp = "N/A"

# Displays customer receipt to user-------------------------------------------------------------------------------------

    print()
    print()
    print("      -- One Stop Insurance Company -- ")
    print("            Auto Policy Receipt ")
    print()
    print("Client Name:", CustFirstNm, CustLastNm)
    print("{}, {}".format(CustStAdd, CustCity))
    print(CustProv)
    print(PostCode)
    print("Phone:", CustPh)
    print()
    print("Policy Number: {:}      Date: {:}".format(POLICY_NUM, d1Dsp))
    print("===========================================")
    print("Vehicles Insured: {:>25}".format(NumCarsDsp))
    if NumCars > 1:
        print("Additional Vehicle(s) Discount: {:>11}".format(DiscountDsp))
    else:
        pass
    print("Premium: {:>34}".format(PremiumCostDsp))
    print("------------Additional Coverage------------")
    if ExtLiability == "Y":
        print("Extra Liability: {:>26} ".format(ExtLiabilityDsp))
    else:
        print("Extra Liability: {:>26} ".format(NADsp))
    if GlassCov == "Y":
        print("Glass Coverage: {:>27} ".format(GlassCovCostDsp))
    else:
        print("Glass Coverage: {:>27} ".format(NADsp))
    if LoanCar == "Y":
        print("Loan Vehicle: {:>29} ".format(LoanCarCostDsp))
        print("-------------------------------------------")
    else:
        print("Loan Vehicle: {:>29} ".format(NADsp))
        print("-------------------------------------------")
    if TotExtra > 0:
        print("Additional Coverage Total: {:>16}".format(TotExtraDsp))
        pass
    print("Premium Total: {:>28}".format(TotPremiumDsp))
    print("HST: {:>38} ".format(TaxesDsp))
    print("                                  ---------")
    print("Total Cost: {:>31} ".format(TotCostDsp))
    print("===========================================")

# Saves user input and calculations to "Policies.dat" data file---------------------------------------------------------

    f = open("Policies.dat", "a")
    f.write("{}, ".format(str(POLICY_NUM)))
    f.write("{}, ".format(CustFirstNm))
    f.write("{}, ".format(CustLastNm))
    f.write("{}, ".format(CustStAdd))
    f.write("{}, ".format(CustCity))
    f.write("{}, ".format(CustProv))
    f.write("{}, ".format(PostCode))
    f.write("{}, ".format(CustPh))
    f.write("{}, ".format(str(NumCars)))
    f.write("{}, ".format(ExtLiability))
    f.write("{}, ".format(GlassCov))
    f.write("{}, ".format(LoanCar))
    f.write("{}, ".format(PolPayMethod))
    f.write("{}, ".format(str(TotExtra)))
    f.write("{}, ".format(str(Premium)))
    TotCost = round(TotPremCost, 2)
    f.write("{}\n".format(str(TotCost)))
    pass

# Saves user input and calculations to "Payments.dat" data file---------------------------------------------------------
    if PolPayMethod == "M":
        print("Payment Arrangement: {:} {:>13}".format("Monthly:", MonthlyPayDsp))
        print()
        print("Note: A one time processing fee of $39.99 ")
        print("has been applied to the monthly payments. ")
        print()
        print()

        f = open("Payments.dat", "a")
        f.write("{}, ".format(str(POLICY_NUM)))
        f.write("{}, ".format(CustFirstNm))
        f.write("{}, ".format(CustLastNm))
        f.write("{}, ".format(PolPayMethod))
        Taxes = round(Taxes, 2)
        f.write("{}, ".format(str(Taxes)))
        f.write("{}, ".format(str(Premium)))
        TotCost = round(TotCost, 2)
        f.write("{}, ".format(str(TotPremium)))
        MonthlyPay = round(MonthlyPay, 2)
        f.write("{}\n".format(str(MonthlyPay)))
        f.close()
        print("Insurance information successfully saved.")

# Rewrites constants and updates Claim_Num to "OSICDef.dat" data file---------------------------------------------------

    POLICY_NUM += 1
    f = open('OSICDef.dat', 'w')
    f.write("{}\n".format(str(POLICY_NUM)))
    f.write("{}\n".format(BASIC_PREM))
    f.write("{}\n".format(ADD_CAR_DISC))
    f.write("{}\n".format(EXTRA_COV))
    f.write("{}\n".format(GLASS_COV))
    f.write("{}\n".format(LOAN_CAR_COV))
    f.write("{}\n".format(str(HST_RATE)))
    f.write("{}\n".format(PROCESS_FEE))
    f.close()
    Cont = input("Would you like to process another policy? (Y = Yes / N = No)").upper()
    if Cont == "Y":
        pass
    else:
        exit()

'''
    if PolPayMethod == "F":
        Cont = input("Would you like to process another policy? (Y = Yes / N = No)").upper()
        if Cont == "Y" or "N":
            f = open("Payments.dat", "w")
            f.write("{}, ".format(str(CLAIM_NUM)))
            f.write("{}, ".format(CustFirstNm))
            f.write("{}, ".format(CustLastNm))
            f.write("{}, ".format(PolPayMethod))
            f.write("{}, ".format(str(Taxes)))
            f.write("{}, ".format(str(PremiumCost)))
            TotCost = round(TotCost, 2)
            f.write("{}, ".format(str(TotCost)))
            MonthlyPay = round(MonthlyPay, 2)
            f.write("{}\n".format(str(MonthlyPay)))
            f.close()

            print("Insurance information successfully saved.")
            POLIICY_NUM += 1
            f = open('OSICDef.dat', 'w')
            f.write("{}\n".format(str(CLAIM_NUM)))
            f.write("{}\n".format(BASIC_PREM))
            f.write("{}\n".format(ADD_CAR_DISC))
            f.write("{}\n".format(EXTRA_COV))
            f.write("{}\n".format(GLASS_COV))
            f.write("{}\n".format(LOAN_CAR_COV))
            f.write("{}\n".format(str(HST_RATE)))
            f.write("{}\n".format(PROCESS_FEE))
            f.close()
'''